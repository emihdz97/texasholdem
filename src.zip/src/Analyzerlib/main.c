#include "analyzer.h"

int main () {

	//Usage
    getScore(0, 4, 8, 12, 16, 20, 24);



   return(0);
} 


